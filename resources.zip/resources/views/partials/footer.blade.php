<footer class="main-footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12">
                <p>&copy; {{$general_setting->site_title}} | {{trans('file.Developed')}} {{trans('file.By')}} <span
                        class="external">{{$general_setting->developed_by}}</span></p>
            </div>
        </div>
    </div>
</footer>
